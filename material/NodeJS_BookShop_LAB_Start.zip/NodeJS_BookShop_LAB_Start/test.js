var express = require('express');
var cors = require('cors');
const app = express()

//dotenv
const dotenv = require('dotenv');
dotenv.config();


//MYSQL Connection
var db = require('./config/db.js');

//File upload
var fileUpload = require('express-fileupload');
app.use(fileUpload());

const port = process.env.PORT || 3000


app.listen(port, () => {
  console.log(`Book Shop API ... listening at http://localhost:${port}`)
});

//---JSON and URL Encode
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true
  })
);

app.use(cors());




// 1) -------- Get all books








// 2) -------- Add new book








// 3) -------- Get book by id








// 4) -------- Delete book by id









// 5) -------- Edit book by id






